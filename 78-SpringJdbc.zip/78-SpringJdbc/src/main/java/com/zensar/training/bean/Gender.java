package com.zensar.training.bean;

public enum Gender {
	MALE,FEMALE;
}
